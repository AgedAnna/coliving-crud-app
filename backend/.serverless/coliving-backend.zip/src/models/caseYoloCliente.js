/**
 * @typedef {Object} CaseYoloCliente
 * @property {string} Nome
 * @property {string} Telefone
 * @property {string} E-mail
 * @property {string} Tipo
 * @property {string}
 */

module.exports = {};
